<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$sql=$con->prepare("SELECT city.sr_id,city.sr_name as city,state.sr_name as state ,country.sr_name as country FROM city,state,country WHERE state.country_id = country.sr_id AND city.state_id=state.sr_id");
$sql->execute([]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);
?>

<html>
<body>
	<h1>CITY</h1>

	<form method="POST" action="">
	<table>
		<tr>
		<td><b>CITY<b></td>
		<td><b>STATE<b></td>
		<td><b>NAME OF COUNTRY<b></td>
		
		</tr>

<?php

if(!empty($result))
{
	foreach ($result as $data) {


?>
		
		<tr>
		<td><input type="text"  value="<?php echo $data['city']  ?>"></td>
		<td><input type="text"  value="<?php echo $data['state']  ?>"></td>	
		<td><input type="text"  value="<?php echo $data['country']  ?>"></td>
		</td><td><a href="city_edit.php?id=<?php echo $data['sr_id']?>"><input type="button" value="EDIT"></a></td>
		

<?php
	
	}
}

?>

<tr><tr><tr>
<tr><tr><tr>
<tr>
	<td>
	
	
<a href="city_add.php"><input type="button" value="ADD"></a>


</td>
</tr>

</table>

</form>

</body>
</html>

