<?php
//print_r($_GET);die();
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$id=$_GET['id'];
//print_r($id);
$sql=$con->prepare("SELECT state.sr_id,state.sr_name as state ,country.sr_name as country FROM state INNER JOIN country ON state.country_id = country.sr_id where state.sr_id=?");
$sql->execute([$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();

?>


<html>
<body>
	<h1>STATE EDIT</h1>

	<form method="POST" action="state_edit_info.php">
	<table>
	
	<tr>
		<td>SELECT COUNTRY</td>
		<td><input type="text" name="sc" value="<?php echo $result[0]['country'] ?>"></td>
		</tr>
			

		<tr>
		<td>ENTER STATE NAME</td>
		<td><input type="text" name="esn" value="<?php echo $result[0]['state'] ?>"></td>
		<td><input type="hidden" name="hidden" value="<?php echo $result[0]['sr_id'] ?>"></td>
		</tr>
			<tr>
				<tr>
					<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>
	</tr>
</tr>


</table>
</form>
</body>
</html>

