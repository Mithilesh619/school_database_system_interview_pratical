<?php
error_reporting(0);
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$id=$_POST['id'];
$type=$_POST['type'];

if($type=='city'){
	$sql="select sr_id,sr_name from city where state_id='$id'";
}else{
	$sql="select sr_id,sr_name from state where country_id='$id'";
}
$stmt=$con->prepare($sql);
$stmt->execute();
$arr=$stmt->fetchAll(PDO::FETCH_ASSOC);
$html='';
foreach($arr as $list){
	$html.='<option value='.$list['sr_id'].'>'.$list['sr_name'].'</option>';
}
echo $html;
?>