<?php
//print_r($_POST);die();

$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
if($_POST['hidden']!='')
{
$id=$_POST['hidden'];
$password=$_POST['password'];
$encry_pass=md5($password);
$sql=$con->prepare("update user set password=? where sr_id=?");
$sql->execute([$encry_pass,$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
//echo  '<script>alert("country added succefully")</script>';
}
header('location:login.php');
?>
