<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$sql=$con->prepare("select s.sr_name,s.tel_no,s.email_id,s.dob,c.class_name,c.tel_no,c.no_of_student,c.floor,t.teach_name,ct.sr_name as teacher_city FROM student s INNER JOIN class c on s.class_id=c.sr_id INNER join teacher t on s.teach_id=t.sr_id INNER JOIN city ct on t.city_name=ct.sr_id");
$sql->execute();
$selectData=$sql->fetchAll(PDO::FETCH_ASSOC);


$csvColoum = array("StudentName","Telno","StudenEmail","StudentDOB","ClassName","ClassTelNo","ClassNoOfStudents","ClassFloor","TeacherName","TecherCity");  
date_default_timezone_set('Europe/London');
$currentdate = date('Y-m-d_H:i:s');

$flag = false;
$filename = "StudentDatabaseSystem-" . $currentdate . ".xls";
header('Content-Disposition: attachment; filename="' . $filename . '";');
header('Content-Type: application/vnd.ms-excel');
header("Content-Type: text/plain");
if (!$flag) {  
    echo ucwords(implode("\t", $csvColoum)) . "\r\n";
    $flag = true;  
}  
foreach ($selectData as $value) {     
    $empdata = array(
        'std_name' => $value['sr_name'],
        'tel' => $value['tel_no'],
        'email' => $value['email_id'],
        'dob' => $value['dob'],
        'class_name' => $value['class_name'],
        'tel_no' => $value['tel_no'],
        'no_of_std' => $value['no_of_student'],
        'floor' => $value['floor'],
        'teach_name' => $value['teach_name'],
        'teacher_city' => $value['teacher_city']
      
    );
    echo implode("\t", $empdata) . "\r\n";
}
exit;

