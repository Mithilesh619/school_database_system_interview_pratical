<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$sql=$con->prepare("select * from user");
$sql->execute([]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
?>

<html>
<body>
	<h1>USER MANAGER</h1>

	<form method="POST" action="">
	<table>
		<tr>
		<td><b>PHOTO<b></td>
		<td><b>NAME<b></td>
		<td><b>EMP ID<b></td>
		<td><b>USERNAME<b></td>
		<td><b>ACTION<b></td>

		</tr>

<?php

if(!empty($result))
{
	foreach ($result as $data) {
	
?>
		
		<tr>
		<td><input type="text" name="picture" value="<?php echo $data['picture']  ?>"></td>
		<td><input type="text" name="name" value="<?php echo $data['sr_name']  ?>"></td>
		<td><input type="text" name="emp_id" value="<?php echo $data['emp_id']  ?>"></td>
		<td><input type="text" name="username" value="<?php echo $data['user_name']  ?>"></td>
		</td><td><a href="edit_user_manager.php?id=<?php echo $data['sr_id']?>"><input type="button" value="EDIT"></a></td>
		

<?php
	
	}
}

?>
<tr><tr><tr>
<tr><tr><tr>
<tr>
	<td>
	
	
<a href="user.php"><input type="button" value="ADD"></a>


</td>
</tr>

</table>

</form>

</body>
</html>
