<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
if(!empty($_POST))
{
$ecn=$_POST['ecn'];
$sql=$con->prepare("insert into country (sr_name) values(?)");
$sql->execute([$ecn]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);

echo  '<script>alert("country added succefully")</script>';
//echo "Country added succefully";
//echo "<pre>";print_r($result);die();

}
header('location:country.php');
?>
