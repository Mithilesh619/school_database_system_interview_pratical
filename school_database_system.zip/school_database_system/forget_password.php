<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Reset Page</title>
</head>
<body>
	<h3>FORGOT PASSWORD
</h3>
	<form method="POST" action="forget_password_action.php">
	<table>

		<tr>
		<td>USERNAME</td>
		<td><input type="email" name="username"></td>
		</tr>


		<tr>
		<td>EMP ID</td>
		<td><input type="text" name="emp_id" ></td>
		</tr>
	
				
			<tr>
			<td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>

</table>	
</form>

</body>
</html>