<?php
//print_r($_POST);die();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
if(!empty($_POST))
{
$country_id=$_POST['country'];
$ecn=$_POST['ecn'];
$sql=$con->prepare("insert into state (sr_name,country_id) values(?,?)");
$sql->execute([$ecn,$country_id]);
//$result=$sql->fetchAll(PDO::FETCH_ASSOC);

echo  '<script>alert("country added succefully")</script>';
}
header('location:state.php');
?>
