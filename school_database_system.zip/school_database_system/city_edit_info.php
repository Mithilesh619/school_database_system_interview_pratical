<?php
//print_r($_POST);die();

$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
if($_POST['hidden']!='')
{
$sc=$_POST['sc'];
$ss=$_POST['ss'];
$ec=$_POST['ec'];
$id=$_POST['hidden'];

$sql=$con->prepare("update city set sr_name=? where sr_id=?");
$sql->execute([$ec,$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
echo  '<script>alert("country added succefully")</script>';
echo "Country edited succefully";
}
header('location:city.php');
?>
