<?php
//print_r($_GET);die();
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$id=$_GET['id'];
//print_r($id);
$sql=$con->prepare("select * from country where sr_id=?");
$sql->execute([$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);

?>


<html>
<body>
	<h1>COUNTRY EDIT</h1>

	<form method="POST" action="country_edit_info.php">
	<table>
		<tr>
		
		<td>ENTER COUNTRY NAME</td>
		<td><input type="text" name="eecn" value="<?php echo $result[0]['sr_name'] ?>"></td>
		<td><input type="hidden" name="hidden" value="<?php echo $result[0]['sr_id'] ?>"></td>
		</tr>
			<tr>
				<tr>
					<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>
	</tr>
</tr>


</table>
</form>
</body>
</html>

