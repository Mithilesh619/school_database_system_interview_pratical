<div align="right"><a href="login.php"><input type="button" name="logout" value="LOGOUT"></a></div>

<?php

session_start();

$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
//print_r($_SESSION);die();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Dashboard</title>
</head>
	


</head>
<body>
<h1>welcome <?php echo $_SESSION['name'] ?></h1>







<ul>
  <li><b>MASTER</b></li>
  <a href="country.php"><li>COUNTRY</a></li>
  <a href="state.php"><li>STATE</a></li>
  <a href="city.php"><li>CITY</a></li>
</ul>
<ul>
	<ul>
		<li>
<a a href="user_manager.php"><li><b>USER MANAGER</b></a></li>
<a a href="xls.php"><li><b>Download Xls File</b></a></li>
</li>	

	</ul>

</body>
</html>




