<?php 

print_r($_GET);
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$id=$_GET['id'];
//print_r($id);
$sql=$con->prepare("select * from user where emp_id=?");
$sql->execute([$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>";print_r($result);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Update Password</title>
</head>
<body>
	<h3>UPDATE PASSWORD</h3>
	<form method="POST" action="update_password_info.php">
	<table>
		<tr>
		<td>PASSWORD</td>
		<td><input type="Password" name="password" placeholder="Enter New Password"></td>
		<td><input type="hidden" name="hidden" value="<?php echo $result[0]['sr_id'] ?>"></td>
		
		</tr>
	
				
			<tr>
			<td align="center" colspan="2">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" name="" value="UPDATE">
			

			</td>
		</tr>

		

</table>	
</form>

</body>
</html>