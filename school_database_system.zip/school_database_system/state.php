<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$sql=$con->prepare("SELECT state.sr_id,state.sr_name as state ,country.sr_name as country FROM state INNER JOIN country ON state.country_id = country.sr_id");
$sql->execute([]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
?>

<html>
<body>
	<h1>STATE</h1>

	<form method="POST" action="">
	<table>
		<tr>
		<td><b>STATE<b></td>
		<td><b>NAME OF COUNTRY<b></td>
		
		</tr>

<?php

if(!empty($result))
{
	foreach ($result as $data) {


?>
		
		<tr>
		<td><?php echo $data['state']  ?></td>	
		<td><?php echo $data['country']  ?></td>
		</td><td><a href="state_edit.php?id=<?php echo $data['sr_id']?>"><input type="button" value="EDIT"></a></td>
		

<?php
	
	}
}

?>

<tr><tr><tr>
<tr><tr><tr>
<tr>
	<td>
	
	
<a href="state_add.php"><input type="button" value="ADD"></a>


</td>
</tr>

</table>

</form>

</body>
</html>

