<?php
//print_r($_POST);die();

$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
if($_POST['hidden']!='')
{
$sc=$_POST['sc'];
$esn=$_POST['esn'];
$id=$_POST['hidden'];

$sql=$con->prepare("update state set sr_name=? where sr_id=?");
$sql->execute([$esn,$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
echo  '<script>alert("country added succefully")</script>';
echo "Country edited succefully";
}
header('location:state.php');
?>
