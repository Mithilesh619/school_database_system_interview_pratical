<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$sql=$con->prepare("select * from country");
$sql->execute([]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
?>

<html>
<body>
	<h1>COUNTRY</h1>

	<form method="POST" action="">
	<table>
		<tr>
		
		<td><b>NAME OF COUNTRY<b></td>
		
		</tr>

<?php

if(!empty($result))
{
	foreach ($result as $data) {
	
?>
		
		<tr>
		<td><?php echo $data['sr_name']  ?></td>
		</td><td><a href="country_edit.php?id=<?php echo $data['sr_id']?>"><input type="button" value="EDIT"></a></td>
		

<?php
	
	}
}

?>
<tr><tr><tr>
<tr><tr><tr>
<tr>
	<td>
	
	
<a href="country_add.php"><input type="button" value="ADD"></a>


</td>
</tr>

</table>

</form>

</body>
</html>
