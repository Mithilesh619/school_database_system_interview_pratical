<?php
//print_r($_POST);die();
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
if(!empty($_POST))
{
$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];
$sql=$con->prepare("insert into city (sr_name,state_id) values(?,?)");
$sql->execute([$city,$state]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);

echo  '<script>alert("country added succefully")</script>';
//echo "Country added succefully";
//echo "<pre>";print_r($result);die();

}
header('location:city.php');
?>
