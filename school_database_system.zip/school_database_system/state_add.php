<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$sql=$con->prepare("select sr_id,sr_name from country");
$sql->execute([]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();
?>

<html>
<body>
	<h1>STATE ADD</h1>

	<form method="POST" action="state_add_info.php">
	<table>
		
		<tr>
		<td>SELECT COUNTRY</td>
		<td><select name="country">
		<?php
		foreach ($result as $value) { 
			//print_r($value);
			 ?>
                 <option value="<?=$value['sr_id']?>"><?=$value['sr_name']?></option>
		<?php  } 
		?> 
		 </select></td>
		</tr>
		
		<tr>
		<td>ENTER STATE NAME</td>
		<td><input type="text" name="ecn"></td>
		</tr>
			<tr>
				<tr>
					<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>
	</tr>
</tr>


</table>
</form>
</body>
</html>

