<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$username = $_POST['username'];
$password = $_POST['password'];
$encrypt_pass= md5($password);  
$sql=$con->prepare("select * from user where user_name=? and password=?");
$sql->execute(array($username,$encrypt_pass)); 
$result = $sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>"; print_r($result);die();  
 
$count=count($result);
if($count=='1')
{
//	print_r($count);die();
session_start();
$_SESSION['name']=$result[0]['sr_name'];
$_SESSION['id']=$result[0]['sr_id'];
header('location:dashboard.php');
}
elseif($count>='2'){
//alert('Too many Username');
//echo "incorrect";
header('location:login.php');
}
else
{
//alert('Incorrect Username OR Password');
//echo "incorrect";
header('location:login.php');   
}
?>