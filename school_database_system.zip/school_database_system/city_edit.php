<?php
//print_r($_GET);die();
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$id=$_GET['id'];
//print_r($id);
$sql=$con->prepare("SELECT city.sr_id,city.sr_name as city,state.sr_name as state ,country.sr_name as country FROM city,state,country WHERE state.country_id = country.sr_id AND city.state_id=state.sr_id and city.sr_id=?");
$sql->execute([$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);
?>


<html>
<body>
	<h1>CITY EDIT</h1>

	<form method="POST" action="city_edit_info.php">
	<table>
	
	<tr>
		<td>SELECT COUNTRY</td>
		<td><input type="text" name="sc" value="<?php echo $result[0]['country'] ?>"></td>
		</tr>
			

		<tr>
		<td>SELECT STATE</td>
		<td><input type="text" name="ss" value="<?php echo $result[0]['state'] ?>"></td>
		</tr>

		<tr>
        <td>ENTER CITY</td>
		<td><input type="text" name="ec" value="<?php echo $result[0]['city'] ?>"></td>
		<td><input type="hidden" name="hidden" value="<?php echo $result[0]['sr_id'] ?>"></td>
		</tr>
			<tr>
				<tr>
					<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>
	</tr>
</tr>


</table>
</form>
</body>
</html>

