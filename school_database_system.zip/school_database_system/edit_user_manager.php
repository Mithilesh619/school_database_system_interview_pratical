<?php
//print_r($_GET);
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
$id=$_GET['id'];
//print_r($id);
$sql=$con->prepare("select * from user where sr_id=?");
$sql->execute([$id]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($result);die();

?>

<html>
<head>
	<meta charset="utf-8">
	<title>EDIT USER MANAGER</title>
</head>
<body>
	<h1>EDIT USER MANAGER</h1>
	<form method="POST" action="userinfo.php" enctype="multipart/form-data">
	<table>


		<tr>
		<td>PICTURE</td>
		<td><input type="file" required="" name="picture" value="<?php echo $result[0]['picture'] ?>"></td>
		<td><input type="hidden" name="hidden" id="h_1" value="<?php echo $result[0]['sr_id'] ?>"></td>
		</tr>


		<tr>
		<td>NAME</td>
		<td><input type="text" name="name" value="<?php echo $result[0]['sr_name'] ?>"></td>
		</tr>

		<tr>
		<td>EMP ID</td>
		<td><input type="text" name="emp_id" value="<?php echo $result[0]['emp_id'] ?>"></td>
		</tr>

		<tr>
		<td>USERNAME</td>
		<td><input type="email" name="username" value="<?php echo $result[0]['user_name'] ?>"></td>
		</tr>
			<tr>
			<td align="center" colspan="2">
				<input type="submit" name="" value="UPDATE">
			</td>
		</tr>

</table>	
</form>
