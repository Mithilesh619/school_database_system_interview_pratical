<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("error in connecting Database");
//echo "Database connected Successfully"; 
//print_r($_POST);die();
if($_POST['hidden']!='')
{
	$file=$_FILES['picture']['name'];
	$tmp_name=$_FILES['picture']['tmp_name'];
	//echo $file;die();
	$path="picture/".$file;
	move_uploaded_file($tmp_name,$path);
	$name=$_POST['name'];
	$id=$_POST['hidden'];
	$emp_id=$_POST['emp_id'];
	$username=$_POST['username'];
	
	
$sql=$con->prepare("update user set picture=?,sr_name=?,emp_id=?,user_name=? where sr_id=?");
$sql->execute([$file,$name,$emp_id,$username,$id]);
header('location:user_manager.php');
}





elseif(!empty($_POST))
{

//if($_POST['name']!='' && $_POST['emp_id']!='' && $_POST['username']!='' && $_POST['password']!='' && $_POST['picture']!='' && $_POST['country']!='' && $_POST['state']!='' && $_POST['city']!='')
//{
	
	$name=$_POST['name'];
	$emp_id=$_POST['emp_id'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$encrypt_pass=md5($password);
	$file=$_FILES['picture']['name'];
	$tmp_name=$_FILES['picture']['tmp_name'];
	//echo $file;die();
	$path="picture/".$file;
	move_uploaded_file($tmp_name,$path);
	$country=$_POST['country'];
	$state=$_POST['state'];
	$city=$_POST['city'];

$sql=$con->prepare("insert into user (sr_name,emp_id,user_name,password,country_id,state_id,city_id,picture) values (?,?,?,?,?,?,?,?)");
$sql->execute([$name,$emp_id,$username,$encrypt_pass,$country,$state,$city,$file]);

//echo "Data inserted Successfully";
header('location:login.php');
}


else
{
	header('location:user.php'); 
}

//}
?> 
  