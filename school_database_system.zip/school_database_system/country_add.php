<html>
<body>
	<h1>COUNTRY ADD</h1>

	<form method="POST" action="country_add_info.php">
	<table>
		<tr>
		
		<td>ENTER COUNTRY NAME</td>
		<td><input type="text" name="ecn"></td>
		</tr>
			<tr>
				<tr>
					<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>
	</tr>
</tr>


</table>
</form>
</body>
</html>

