<?php 

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login Page</title>
</head>
<body>
	<h3>LOGIN</h3>
	<form method="POST" action="login_action.php">
	<table>

		<tr>
		<td>USERNAME</td>
		<td><input type="email" name="username"></td>
		</tr>


		<tr>
		<td>PASSWORD</td>
		<td><input type="Password" name="password" ></td>
		</tr>
	
				
			<tr>
			<td align="center" colspan="2">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" name="" value="SUBMIT">
			

			</td>
		</tr>

		

		<tr>
			<td>
		<a href="forget_password.php">FORGOT PASSWORD</a></td>
	</tr>			

</table>	
</form>

</body>
</html>