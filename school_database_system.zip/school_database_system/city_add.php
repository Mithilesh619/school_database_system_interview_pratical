<?php
$con=new PDO("mysql:hostname=localhost;dbname=school_database_system","root","") or die("Error in Connecting Database");
$sql=$con->prepare("select sr_id ,sr_name from country");
$sql->execute([]);
$result=$sql->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>";print_r($result);
?>

<html>
<body>
	<h1>CITY ADD</h1>

	<form method="POST" action="city_add_info.php">
	<table>
		
		<tr>
		<td>COUNTRY</td>
		<td>
		<select id="country" name="country" required>
		<option value="-1">Country</option>
		<?php
		foreach($result as $country){
		?>
		<option value="<?php echo $country['sr_id']?>"><?php echo $country['sr_name']?></option>
		<?php
		}
		?>
		</select>
		</td>
	</tr>

	<tr>
		<td>State</td>
		<td>
		<select id="state" name="state" required>
		<option>Select State</option>
		</select>
	</td>
</tr>
		
<tr>
		<td>City</td>
		<td>
		<input type="text" name="city" required>
	</td>
</tr>
		
				
			<tr>
			<td align="center" colspan="2">
				<input type="submit" name="" value="SUBMIT">
			</td>
		</tr>

</table>	
</form>
<div id="divLoading"></div>
	<style>
	#divLoading	{
		display : none;
	}
	#divLoading.show{
		display : block;
		position : fixed;
		z-index: 100;
		background-image : url('http://loadinggif.com/images/image-selection/3.gif');
		background-color:#666;
		opacity : 0.4;
		background-repeat : no-repeat;
		background-position : center;
		left : 0;
		bottom : 0;
		right : 0;
		top : 0;
	}
	#loadinggif.show {left : 50%;
		top : 50%;
		position : absolute;
		z-index : 101;
		width : 32px;
		height : 32px;
		margin-left : -16px;
		margin-top : -16px;
	}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script>
	$(document).ready(function(){
		jQuery('#country').change(function(){
			var id=jQuery(this).val();
			//alert(id);
			if(id=='-1'){
				jQuery('#state').html('<option value="-1">Select State</option>');
			}else{
				$("#divLoading").addClass('show');
				jQuery('#state').html('<option value="-1">Select State</option>');
				jQuery('#city').html('<option value="-1">Select City</option>');
				jQuery.ajax({
					type:'post',
					url:'get_data.php',
					data:'id='+id+'&type=state',
					success:function(result){
						//alert(result);
						$("#divLoading").removeClass('show');
						jQuery('#state').append(result);
					}
				});
			}
		});
	});
	</script>	
</body>
</html>